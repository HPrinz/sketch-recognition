#!/usr/bin/env bash

# for f in `find . -name "*.png"`
# do
#    convert ${f} -trim +repage -resize 28x28 -background white -gravity center -extent 28x28 ${f}
# done

for category in */ ; do
    echo "extracting for category $category"
    mkdir "../tu-test-small/${category}"

    i=0
    for x in ${category}/*; do
      if [ "$i" = 10 ]; then break; fi
      mv -- "${x}" "../tu-test-small/${category}"
      i=$((i+1))
    done

done